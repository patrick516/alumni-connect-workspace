import type { Job } from "../types";
import { api, getErrorMessage } from "./client";

export async function getJobsApi(): Promise<Job[]> {
  try {
    const { data } = await api.get<Job[]>("/jobs");
    return data;
  } catch (e) {
    throw new Error(getErrorMessage(e, "Failed to fetch jobs"));
  }
}

export async function createJobApi(data: Partial<Job>): Promise<Job> {
  try {
    const { data: job } = await api.post<Job>("/jobs", data);
    return job;
  } catch (e) {
    throw new Error(getErrorMessage(e, "Failed to create job"));
  }
}

export async function deleteJobApi(id: string): Promise<void> {
  try {
    await api.delete(`/jobs/${id}`);
  } catch (e) {
    throw new Error(getErrorMessage(e, "Failed to delete job"));
  }
}

export async function approveJobApi(id: string): Promise<void> {
  try {
    await api.put(`/admin/approve-job/${id}`);
  } catch (e) {
    throw new Error(getErrorMessage(e, "Failed to approve job"));
  }
}

export async function applyJobApi(id: string): Promise<void> {
  try {
    await api.post(`/jobs/${id}/apply`);
  } catch (e) {
    throw new Error(getErrorMessage(e, "Failed to apply"));
  }
}
